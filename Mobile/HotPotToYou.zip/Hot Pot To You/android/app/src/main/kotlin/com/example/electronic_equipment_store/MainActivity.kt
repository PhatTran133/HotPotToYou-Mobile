package com.example.electronic_equipment_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
