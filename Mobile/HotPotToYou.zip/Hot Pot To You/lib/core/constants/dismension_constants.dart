const double kMediumPadding24 = 24.0; // bigger default padding
const double kBottomBarIconSize20 = 20.0; // size of icon on the bottom bar
const double kDefaultPadding16 = 16.0; // standard padding using default items
const double kItemPadding10 = 10.0; // default padding between child widgets
const double kMinPadding5 = 5.0; // minium default padding
const double kTopPadding8 = 8.0; // default top padding
const double kDefaultCircle14 = 14.0;

const double kDefaultIconSize18 = 18;
