class HotpotIngredientModel{
  int ID;
  int HotpotID;
  int IngredientId;
  HotpotIngredientModel({
    required this.ID,
    required this.HotpotID,
    required this.IngredientId,

  });
}