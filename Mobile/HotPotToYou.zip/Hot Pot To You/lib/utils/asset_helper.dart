class AssetHelper {
  static const String imageSplash = 'assets/images/splash.png';
  static const String imageLogo = 'assets/images/logo.png';
  static const String imageAvatarDefault = 'https://cellphones.com.vn/sforum/wp-content/uploads/2023/10/avatar-trang-4.jpg';

}
